package com.example.health_medicare_application.ui.theme

import androidx.compose.ui.graphics.Color

val purple673 = Color(0xFF673AB7)
val purewhite = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)
val yellow = Color(0xFFDAC720)
