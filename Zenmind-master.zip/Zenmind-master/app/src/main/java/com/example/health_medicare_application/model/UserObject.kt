package com.example.health_medicare_application.model

data class UserObject(
    var userEmail: String,
    var mobile: String,
    var password: String,
    var name: String,
)